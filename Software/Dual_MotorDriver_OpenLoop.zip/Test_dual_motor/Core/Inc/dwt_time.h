/*
 * dwt_time.h
 *
 *  Created on: Aug 17, 2025
 *      Author: zhuoy
 */

#ifndef INC_DWT_TIME_H_
#define INC_DWT_TIME_H_

// === dwt_time.h（若不建头文件，直接放 main.c 顶部也行） ===
#include "stm32g4xx.h"   // G4 系列；若是别的内核换对应头
#include <stdint.h>

static uint32_t cycles_per_us = 0;

static inline void DWT_Init(void)
{
    // 1) 打开 DWT 模块
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;

    // 2) 某些芯片带 Lock Access Register，解锁（没有也不出错）
    volatile uint32_t *DWT_LAR = (uint32_t *)0xE0001FB0;
    *DWT_LAR = 0xC5ACCE55;

    // 3) 复位计数器并启动
    DWT->CYCCNT = 0;
    DWT->CTRL  |= DWT_CTRL_CYCCNTENA_Msk;

    // 4) 计算每微秒的周期数（主频/1e6）
    cycles_per_us = SystemCoreClock / 1000000U;
}

static inline uint32_t micros(void)
{
    // 返回当前时间（微秒）。约每 ~4294 秒回绕一次（无所谓，做差值用无符号减法）。
    return DWT->CYCCNT / cycles_per_us;
}

static inline uint32_t cycles(void)
{
    // 返回当前 CPU 周期计数
    return DWT->CYCCNT;
}

static inline void delay_us(uint32_t us)
{
    uint32_t start = DWT->CYCCNT;
    uint32_t target = us * cycles_per_us;
    while ((uint32_t)(DWT->CYCCNT - start) < target) {
        __NOP();
    }
}


#endif /* INC_DWT_TIME_H_ */
