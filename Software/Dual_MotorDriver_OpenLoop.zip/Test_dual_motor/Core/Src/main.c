/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "usb_device.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <math.h>
#include <unistd.h>
#include <stdbool.h>
#include "arm_math.h"
#include "dwt_time.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
extern UART_HandleTypeDef huart2;
extern TIM_HandleTypeDef htim2;

typedef struct {
    // Hall 相关
    uint8_t hall[3];          // Hall A/B/C 状态（GPIO 读取值）
    float electrical_angle;   // 通过 Hall 状态或 Clarke/Park 解算的电角度
    float electrical_speed;   // 电角速度 (rad/s)，可由 hall 过零计时或编码器解算
    float mechanical_speed;
    uint32_t edges;
    float T_s;


    // 电流采样
    __attribute__((aligned(4))) volatile uint16_t adc_raw[2];      // ADC 原始值（例如 IA, IB）
    float current[2];         // 电流 IA, IB (单位 A)，需要零偏校准
    float current_offset[2];  // 电流采样偏移（空载时校准获得）
    float current_cal[2];

    // 电压测量（可选，如用于母线电压、AB相电压等）
    float voltage[3];         // UA, UB, UC 或其他实际定义

    // 占空比
    float duty_ratio[3];      // 三相 PWM 的占空比（0.0 - 1.0）
    float speed_ref_rpm;
    float speed_filt;      // 低通后的速度反馈 (rpm)
    float speed_cmd_rpm;   // 爬坡后的目标 (rpm)


    // PID控制器可拓展用
    float id_ref, iq_ref;     // 参考电流
    float id, iq;             // 实际电流
    float vd, vq;             // 电压控制量
    float iq_ref_prev;
    float theta_offset;
    // 状态标志
    uint8_t fault_flag;       // 故障标志
} MotorFOC_t;

typedef struct {
    volatile uint32_t prev_us;
    volatile uint32_t now_us;
    volatile uint32_t delta_us;
    volatile uint8_t  updated;
    volatile int8_t   prev_hs;   // 改：int8_t
    volatile int8_t   now_hs;    // 改：int8_t
    volatile uint8_t  invalid;
    volatile uint32_t last_update_us;
} HallStamp_t;

typedef struct {
    uint32_t t_edge_us;
    uint32_t dt_last_us;
    int8_t   sector;
} HallAngle_t;

typedef struct {
    GPIO_TypeDef* A_port; uint16_t A_pin;
    GPIO_TypeDef* B_port; uint16_t B_pin;
    GPIO_TypeDef* C_port; uint16_t C_pin;
} HallPins_t;

typedef struct {
    float kp;              // 比例增益，单位: V / (rpm)
    float ki;              // 积分增益，单位: V / (rpm·s)
    float integ;           // 积分状态
    float out_min, out_max;        // 输出限幅（电压，±V_LIMIT）
    float integ_min, integ_max;    // 积分限幅
} PI_t;

typedef struct {
    volatile uint32_t win_start_us;  // 窗口起始时间（ISR 仅首次置）
    volatile uint32_t edge_count;    // 窗口内沿计数（ISR ++）
    volatile uint32_t last_edge_us;  // 上次“有效沿”时间（ISR 写）
    volatile int8_t   dir_hold;      // 方向（轮询任务里更新；ISR 不改）
} SpdFixedWin_t;


/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define DRV8323_EN_1_GPIO_Port     GPIOC
#define DRV8323_EN_1_Pin           GPIO_PIN_13


#define DRV8323_CS_1_GPIO_Port     GPIOA
#define DRV8323_CS_1_Pin           GPIO_PIN_4


#define DRV8323_EN_2_GPIO_Port     GPIOB
#define DRV8323_EN_2_Pin           GPIO_PIN_7

#define DRV8323_CS_2_GPIO_Port     GPIOB
#define DRV8323_CS_2_Pin           GPIO_PIN_12

// Motor 1 Hall Sensor A/B/C
#define M1_HALL_A_GPIO_Port     GPIOB
#define M1_HALL_A_Pin           GPIO_PIN_4

#define M1_HALL_B_GPIO_Port     GPIOB
#define M1_HALL_B_Pin           GPIO_PIN_5

#define M1_HALL_C_GPIO_Port     GPIOB
#define M1_HALL_C_Pin           GPIO_PIN_6

#define MOTOR_POLE_PAIRS 16
#define V_LIMIT					8

#define ADC_REF_VOLTAGE 		3.3f
#define VREF_DRV8323    		(ADC_REF_VOLTAGE / 2.0f)
#define RSENSE          		0.005f
#define GAIN_CSA        		5.0f
__attribute__((aligned(4))) volatile uint16_t adc_buffer[2] = {0xFFFF, 0xFFFF};


#define PWM_PERIOD   	100
#define CTRL_DT_US    	100
#define PRINT_DT_US   	100000

#define SPEED_LPF_FC_HZ   100.0f
#define TAU_S   (1.0f / (2.0f * 3.1415926f * SPEED_LPF_FC_HZ))

#define OMEGA_OPEN_RAD  (2.0f*PI*60.0f)

#define SPEED_WIN_MS            100
#define SPEED_WIN_US            (SPEED_WIN_MS * 1000)
#define EDGES_PER_MECH_REV_RISING   16
#define EDGES_PER_MECH_REV_BOTH     (2u * 16)
#define RPM_MAX        5000.0f
#define MIN_EDGE_US(P) (uint32_t)(0.2f * (60.0f / (RPM_MAX * (float)(P))) * 1e6f)


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */



static MotorFOC_t motors[2];

static HallStamp_t hall_m[2];
static const uint8_t motor_pole_pairs[2] = { 16, 16 };
static SpdFixedWin_t spd_win[2] = {0};
static float target_e_rads = 0.0f;
static PI_t spdPI;
//static float hall_bemf_offset = 0.0f*PI/180;

static const HallPins_t hall_pins[2] = {
    // M1: PB4/5/6
    { GPIOB, GPIO_PIN_4, GPIOB, GPIO_PIN_5, GPIOB, GPIO_PIN_6 },
    // M2: PC10/11/12
    { GPIOC, GPIO_PIN_10, GPIOC, GPIO_PIN_11, GPIOC, GPIO_PIN_12 },
};

static float rpm_lpf[2] = {0};           // 低通后的 rpm
static uint32_t rpm_lpf_last_us[2] = {0};

static volatile int8_t  dir_sign[2] = { -1, +1 };

static const int8_t hall_to_sector[8] = {
    -1, /*000*/ 0, /*001*/
    2,  /*010*/ 1,  /*011*/
    4,  /*100*/ 5,  /*101*/
    3,  /*110*/ -1   /*111*/
};

static float sector_to_angle[6] = {
	5.2360f,    // sector 0
	4.1888f,   	// sector 1
	3.1416f,  	// sector 2
	2.0944f,  	// sector 3
	1.0472f,  	// sector 4
	0.0f   		// sector 5
};

volatile uint16_t adc5_raw = 0;      // DMA 目标
static const float VDDA = 3.30f;     // 建议后续用 VREFINT 校准替换
static const float K_DIV = 13.0f;
static float VBUS = 36;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint16_t DRV8323_ReadWrite(uint16_t reg, int drv);
void DRV8323_Init(void);

//Current Measurement
void Read_Current_From_DRV8323(float* ia, float* ib, int motor_ID);

//Communication

int _write(int fd, const char *ptr, int len);
//Speed Measurement
static inline int which_motor(uint16_t pin);
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef* h);
void speed_task(int m);
static inline uint8_t hall_state(int m);
void elec_angle_from_hall(MotorFOC_t* motor, HallStamp_t* hall_m, int motorID);
static inline float speed_lpf_update(float rpm_meas, int mid);
void hall_poll_task_1kHz(void);
//FOC
static inline float wrap_pm(float x);
static inline float clampf(float x, float lo, float hi);
static inline void pi_reset(PI_t* pi, float val);
static inline float pi_update(PI_t* pi, float err, float dt);
void setPhaseVoltage(MotorFOC_t* motor, TIM_HandleTypeDef* htim);
void velocityOpenloop(MotorFOC_t* motor, TIM_HandleTypeDef* htim, int motor_ID);
static inline void apply_pwm_duty_abc(float da, float db, float dc, MotorFOC_t* motor, TIM_HandleTypeDef* htim);
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  DWT_Init();
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM1_Init();
  MX_TIM8_Init();
  MX_ADC1_Init();
  MX_ADC2_Init();
  MX_SPI1_Init();
  MX_USB_Device_Init();
  MX_USART2_UART_Init();
  MX_TIM3_Init();
  MX_TIM5_Init();
  MX_ADC5_Init();
  MX_TIM6_Init();
  /* USER CODE BEGIN 2 */
  /* USER CODE BEGIN 2 */

  // —— 安全启动顺序 ——
  spdPI.kp = 0.001f;                 // V / rpm
  spdPI.ki = 0.000f;                // V / (rpm·s)
  spdPI.out_min = -V_LIMIT;          // 例如 ±4V
  spdPI.out_max =  V_LIMIT;
  spdPI.integ_min = -V_LIMIT;
  spdPI.integ_max =  V_LIMIT;
  pi_reset(&spdPI, 0.0f);




  HAL_TIM_IC_Start_IT(&htim3, TIM_CHANNEL_2);  // 电机1（PB5=TIM3_CH2）
  HAL_TIM_IC_Start_IT(&htim5, TIM_CHANNEL_2);  // 电机2（PC12=TIM5_CH2）
  HAL_TIM_Base_Start(&htim6);
  // 1) 先禁止 EN_GATE，确保驱动关断
  HAL_GPIO_WritePin(DRV8323_EN_1_GPIO_Port, DRV8323_EN_1_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(DRV8323_EN_2_GPIO_Port, DRV8323_EN_2_Pin, GPIO_PIN_RESET);

  // 2) 预置 PWM=0（防止启动毛刺）
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 0);
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, 0);
  __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_1, 0);
  __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_2, 0);
  __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_3, 0);

  // 3) 先启动 PWM（输出仍为 0，占空稳定）
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
  HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_1);
  HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_2);
  HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_3);

  HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_3);
  HAL_TIMEx_PWMN_Start(&htim8, TIM_CHANNEL_1);
  HAL_TIMEx_PWMN_Start(&htim8, TIM_CHANNEL_2);
  HAL_TIMEx_PWMN_Start(&htim8, TIM_CHANNEL_3);

  // 4) 这时再拉高 EN_GATE，然后配置 DRV
  HAL_GPIO_WritePin(DRV8323_EN_1_GPIO_Port, DRV8323_EN_1_Pin, GPIO_PIN_SET);
  // 如启用第2路，再拉高 EN_2
  HAL_GPIO_WritePin(DRV8323_EN_2_GPIO_Port, DRV8323_EN_2_Pin, GPIO_PIN_SET);
  HAL_Delay(2);
  DRV8323_Init();

  // 5) 其余外设
  // Avoid Crashing
  HAL_NVIC_DisableIRQ(DMA1_Channel1_IRQn);
  HAL_NVIC_DisableIRQ(ADC1_2_IRQn);
  DMA1->IFCR = (DMA_IFCR_CGIF1 | DMA_IFCR_CTCIF1 | DMA_IFCR_CHTIF1 | DMA_IFCR_CTEIF1);

  HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED);
  HAL_ADC_Start_DMA(&hadc1, (uint32_t*)&motors[0].adc_raw, 2);
  HAL_ADCEx_Calibration_Start(&hadc2, ADC_SINGLE_ENDED);
  HAL_ADC_Start_DMA(&hadc2, (uint32_t*)&motors[1].adc_raw, 2);
  HAL_ADCEx_Calibration_Start(&hadc2, ADC_SINGLE_ENDED);
  HAL_ADC_Start_DMA(&hadc2, (uint32_t*)&motors[1].adc_raw, 2);
  HAL_ADCEx_Calibration_Start(&hadc5, ADC_SINGLE_ENDED);  // 上电校准
  HAL_ADC_Start_DMA(&hadc5, (uint32_t*)&adc5_raw, 1);

  // 目标转速（正负都可，单位 rpm）
  motors[1].speed_ref_rpm 		= 	1000.0f;
  //Current Calibration
  motors[1].current_offset[0] = -0.0056f;
  motors[1].current_offset[1] = 0.03729f;
  motors[1].current_cal[0] = 0.9695f;
  motors[1].current_cal[1]= 0.95396f;
  motors[1].vq = 6.5f;

  HAL_Delay(2);
  printf("FOC1 ready. ARR=%lu, PERIOD=%d\r\n", (uint32_t)htim1.Instance->ARR, PWM_PERIOD);


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  // 10 秒正转 → 10 秒反转，循环
	      uint32_t t_ms = HAL_GetTick() % 20000;   // 0..19999 ms
	      float target_ref = (t_ms < 10000) ? 200.0f : -200.0f;   // 目标电角速度 rad/s

	      // ---- 加速斜坡发生器（限制最大加速度）----
	      static float e_cmd = 0.0f;             // 平滑后的电角速度指令 rad/s
	      static uint32_t last_ms = 0;           // 上次更新时间
	      const float ACC_E_MAX = 2.0f * 3.1415926f * 1.0f; // 最大电角加速度 ≈ 500 el-Hz/s ≈ 3141.6 rad/s^2

	      uint32_t now_ms = HAL_GetTick();
	      float dt = (last_ms == 0) ? 0.001f : (now_ms - last_ms) * 1e-3f; // s
	      if (dt <= 0.0f) dt = 0.001f;
	      if (dt > 0.1f)  dt = 0.1f; // 断续运行保护

	      // 期望变化量，按加速度限幅
	      float de     = target_ref - e_cmd;
	      float de_max = ACC_E_MAX * dt;                  // 本周期允许的最大变化
	      de = clampf(de, -de_max, de_max);               // 限幅
	      e_cmd += de;                                    // 更新平滑指令

	      // ---- 下发到控制 ----
	      target_e_rads = e_cmd;                          // 用平滑后的命令
	      velocityOpenloop(&motors[1], &htim8, 1);


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI48|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSI48State = RCC_HSI48_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV1;
  RCC_OscInitStruct.PLL.PLLN = 42;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV4;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV4;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

uint16_t DRV8323_ReadWrite(uint16_t reg, int drv){
	uint16_t rx;
	if(drv == 1){
		HAL_GPIO_WritePin(DRV8323_CS_1_GPIO_Port, DRV8323_CS_1_Pin, GPIO_PIN_RESET);
		HAL_SPI_TransmitReceive(&hspi1, (uint8_t*)&reg, (uint8_t*)&rx, 1, 10);
		HAL_GPIO_WritePin(DRV8323_CS_1_GPIO_Port, DRV8323_CS_1_Pin, GPIO_PIN_SET);
		HAL_Delay(10);
	}else{

		HAL_GPIO_WritePin(DRV8323_CS_2_GPIO_Port, DRV8323_CS_2_Pin, GPIO_PIN_RESET);
		HAL_SPI_TransmitReceive(&hspi1, (uint8_t*)&reg, (uint8_t*)&rx, 1, 1000);
		HAL_GPIO_WritePin(DRV8323_CS_2_GPIO_Port, DRV8323_CS_2_Pin, GPIO_PIN_SET);
	}


    return rx;
}


void DRV8323_Init(void){
	//Reset Enable Pin
	HAL_GPIO_WritePin(DRV8323_EN_1_GPIO_Port, DRV8323_EN_1_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(DRV8323_EN_2_GPIO_Port, DRV8323_EN_2_Pin, GPIO_PIN_RESET);
	HAL_Delay(1000);

	HAL_GPIO_WritePin(DRV8323_EN_1_GPIO_Port, DRV8323_EN_1_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(DRV8323_EN_2_GPIO_Port, DRV8323_EN_2_Pin, GPIO_PIN_SET);
	HAL_Delay(1000);
	//Initialization
	DRV8323_ReadWrite(0x1001, 1); //address 02:set to 6 PWM mode
	DRV8323_ReadWrite(0x1bFF, 1); //address 03:unlock registers, set side current
	DRV8323_ReadWrite(0x27FF, 1); //address 04
	DRV8323_ReadWrite(0x2B7F, 1); //address 05:set dead time
	DRV8323_ReadWrite(0x321B, 1); //address 06:Auto Calibration
	HAL_Delay(10);
	DRV8323_ReadWrite(0x32C3, 1); //address 06
	HAL_Delay(200);


	printf("=DRV8323 1 Register Configuration=\r\n");
	printf("add0x00 = 0x%04X \r\n", DRV8323_ReadWrite(0x8000, 1));
	printf("add0x01 = 0x%04X \r\n", DRV8323_ReadWrite(0x8800, 1));
	printf("add0x02 = 0x%04X \r\n", DRV8323_ReadWrite(0x9000, 1));
	printf("add0x03 = 0x%04X \r\n", DRV8323_ReadWrite(0x9800, 1));
	printf("add0x04 = 0x%04X \r\n", DRV8323_ReadWrite(0xA000, 1));
	printf("add0x05 = 0x%04X \r\n", DRV8323_ReadWrite(0xA800, 1));
	printf("add0x06 = 0x%04X \r\n", DRV8323_ReadWrite(0xB000, 1));
	printf("================================\r\n");

	DRV8323_ReadWrite(0x1001, 2); //address 02:set to 6 PWM mode
	DRV8323_ReadWrite(0x1b33, 2); //address 03:unlock registers
	DRV8323_ReadWrite(0x2633, 2); //address 04
	DRV8323_ReadWrite(0x2B7F, 2); //address 05:set dead time
	DRV8323_ReadWrite(0x32DB, 2); //address 06:Auto Calibration
	HAL_Delay(10);
	DRV8323_ReadWrite(0x32C3, 2); //address 06
	HAL_Delay(200);


	printf("=DRV8323 2 Register Configuration=\r\n");
	printf("add0x00 = 0x%04X \r\n", DRV8323_ReadWrite(0x8000, 2));
	printf("add0x01 = 0x%04X \r\n", DRV8323_ReadWrite(0x8800, 2));
	printf("add0x02 = 0x%04X \r\n", DRV8323_ReadWrite(0x9000, 2));
	printf("add0x03 = 0x%04X \r\n", DRV8323_ReadWrite(0x9800, 2));
	printf("add0x04 = 0x%04X \r\n", DRV8323_ReadWrite(0xA000, 2));
	printf("add0x05 = 0x%04X \r\n", DRV8323_ReadWrite(0xA800, 2));
	printf("add0x06 = 0x%04X \r\n", DRV8323_ReadWrite(0xB000, 2));
	printf("================================\r\n");


}

int _write(int fd, const char *p, int len){
  if (fd==STDOUT_FILENO || fd==STDERR_FILENO){
    HAL_UART_Transmit(&huart2, (uint8_t*)p, len, 150); // 50ms
    return len;
  }
  return 0;
}

void Read_Current_From_DRV8323(float* ia, float* ib, int motorID)
{
    float v_ia = (motors[motorID].adc_raw[0] / 4095.0f) * ADC_REF_VOLTAGE;
    float v_ib = (motors[motorID].adc_raw[1] / 4095.0f) * ADC_REF_VOLTAGE;
    //printf("adc raw A: %u, adc raw B: %u\r\n", adc_buffer[0], adc_buffer[1]);

    *ia = ((v_ia - VREF_DRV8323) / (GAIN_CSA * RSENSE) - motors[motorID].current_offset[0]) * motors[motorID].current_cal[0];
    *ib = ((v_ib - VREF_DRV8323) / (GAIN_CSA * RSENSE) - motors[motorID].current_offset[1]) * motors[motorID].current_cal[1];
}

static inline int which_motor(uint16_t pin){
    switch(pin){
        case GPIO_PIN_4:
        case GPIO_PIN_5:
        case GPIO_PIN_6:  return 0;
        case GPIO_PIN_10:
        case GPIO_PIN_11:
        case GPIO_PIN_12: return 1;
        default:          return -1;
    }
}

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef* h)
{
	uint8_t m = (h->Instance==TIM3) ? 0 : (h->Instance==TIM5) ? 1 : 0xFF;
	    if (m==0xFF || h->Channel!=HAL_TIM_ACTIVE_CHANNEL_2) return;

	    uint32_t now_us = micros();
	    hall_m[m].last_update_us = now_us;
	    hall_m[m].prev_hs = hall_m[m].now_hs;
	    hall_m[m].now_hs = hall_state(m);
	    if(hall_m[m].prev_hs == hall_m[m].now_hs) return;
	    // —— 最小时间间隔去抖（仍然不算方向/角度）——
	    uint32_t guard = MIN_EDGE_US(motor_pole_pairs[m]);   // P 为该电机极对数
	    uint32_t last  = spd_win[m].last_edge_us;
	    if (last && (now_us - last) < guard) return;         // 丢毛刺/重复沿
	    spd_win[m].last_edge_us = now_us;
	    //printf("%d\r\n",hall_state(m));
	    spd_win[m].edge_count++;
	    if (spd_win[m].win_start_us == 0) spd_win[m].win_start_us = now_us;
}



static inline uint8_t hall_state(int m){
    const HallPins_t *p = &hall_pins[m];
    uint8_t a = HAL_GPIO_ReadPin(p->A_port, p->A_pin);
    uint8_t b = HAL_GPIO_ReadPin(p->B_port, p->B_pin);
    uint8_t c = HAL_GPIO_ReadPin(p->C_port, p->C_pin);
    return hall_to_sector[((a<<2) | (b<<1) | c)];
}


void speed_task(int m)
{
    uint32_t now = micros();
    SpdFixedWin_t *W = &spd_win[m];
    if (W->win_start_us == 0) return;

    if ((now - W->win_start_us) >= SPEED_WIN_US) {
    	int prev = hall_m[m].prev_hs, next = hall_m[m].now_hs;
		int delta = (next - prev + 6) % 6;
		if (delta == 1) { spd_win[m].dir_hold = +1;  }
		else if (delta == 2) { spd_win[m].dir_hold = +1;}

		else if (delta == 5) { spd_win[m].dir_hold = -1; }
		else if (delta == 4) { spd_win[m].dir_hold = -1; }

		else if (delta == 3) {
			if ((prev==1 && next==4) || (prev==4 && next==1)) spd_win[m].dir_hold = +1;
			else if ((prev==0 && next==3) || (prev==3 && next==0)||(prev==2 && next==5) || (prev==5 && next==2)) spd_win[m].dir_hold = -1;
			else { hall_m[m].updated = 0; return; }
		} else { hall_m[m].updated = 0; return; }
        // —— 原子快照 ——（避免读到一半被 ISR ++ 或清零时丢计数）
        uint32_t edges_snapshot, T_us;
        __disable_irq();
        edges_snapshot  = W->edge_count;
        W->edge_count   = 0;
        T_us            = now - W->win_start_us;
        W->win_start_us = now;
        __enable_irq();

        float T_s = (float)T_us * 1e-6f;

        // Rising-only：每机械一圈 = P 个沿
        const uint32_t edges_per_mech_rev = 2*motor_pole_pairs[m];

        // 方向取轮询结果；未初始化（0）时按 +1
        int dir = (W->dir_hold == 0) ? +1 : W->dir_hold;

        float rpm_inst = 0.0f;
        if (edges_snapshot > 0 && edges_per_mech_rev > 0 && T_s > 0.f) {
        	//edges_snapshot = speed_lpf_update(edges_snapshot, m);
            float revs = (float)edges_snapshot / (float)edges_per_mech_rev;
            rpm_inst   = (revs / T_s) * 60.0f * (float)dir;
        }

        motors[m].mechanical_speed = rpm_inst;
        motors[m].electrical_speed = rpm_inst * (2.0f*PI/60.0f) * motor_pole_pairs[m];
    }
}


static inline float speed_lpf_update(float rpm_meas, int mid)
{
    uint32_t now = micros();
    uint32_t last = rpm_lpf_last_us[mid];
    rpm_lpf_last_us[mid] = now;

    if (last == 0) { rpm_lpf[mid] = rpm_meas; return rpm_lpf[mid]; }

    float dt = (now - last) * 1e-6f;          // s
    if (dt < 1e-6f) dt = 1e-6f;
    if (dt > 0.1f)  dt = 0.1f;                // >100ms 就当 100ms

    // 自适应 alpha
    float x = -dt / TAU_S;
    float y;
    arm_vexp_f32(&x, &y, 1);   // 计算 y = exp(x)
    float alpha = 1.0f - y;
    rpm_lpf[mid] += alpha * (rpm_meas - rpm_lpf[mid]);
    return rpm_lpf[mid];
}

static inline float wrap_pm(float x){           // wrap到(-pi,pi]
    while (x >  2.f*PI) x -= 2.f*PI;
    while (x <= 0) x += 2.f*PI;
    return x;
}

void elec_angle_from_hall(MotorFOC_t* motor, HallStamp_t* hm, int motorID)
{
    uint32_t now_us = micros();
    float dt = (hm->last_update_us==0) ? 0.f : (now_us - hm->last_update_us) * 1e-6f;
    if (dt > 0.02f) dt = 0.02f;
    float dir = 1;
    dir = (target_e_rads < 0) ? -1 : 1;
    motor->electrical_angle = dir * sector_to_angle[hm->now_hs] + target_e_rads * dt;

    motor->electrical_angle = wrap_pm(motor->electrical_angle);

	/*const uint32_t HALL_OK_US = 50000; // 50 ms
	if (now_us - hm->last_update_us <= HALL_OK_US && hm->now_hs >= 0 && hm->now_hs < 6) {
		float target = dir_sign[motorID] * sector_to_angle[hm->now_hs];
		float err = wrap_pm(target - motor->electrical_angle);
		const float k_lock = 0.2f;     // 0.1~0.3 都可，避免“硬重置到扇区中心”
		motor->electrical_angle += k_lock * err;
	} else {
		float dir = (motors[motorID].speed_ref_rpm >= 0) ? +1.f : -1.f;
		const float OMEGA_OPEN = 2.f * (float)M_PI * 20.f; // 20 electrical Hz，足够温柔
		motor->electrical_angle += dir_sign[motorID] * dir * OMEGA_OPEN * dt;
	}*/
}
static inline float clampf(float x, float lo, float hi){
    return (x < lo) ? lo : (x > hi ? hi : x);
}

static inline void pi_reset(PI_t* pi, float val){
    pi->integ = clampf(val, pi->integ_min, pi->integ_max);
}

// 条件积分的防饱和（简单稳妥）
static inline float pi_update(PI_t* pi, float err, float dt){
    // 先用当前积分预测输出
    float u_unsat = pi->kp * err + pi->integ;
    // 饱和
    float u = clampf(u_unsat, pi->out_min, pi->out_max);

    // 只有在未饱和，或饱和但积分方向“有利于脱离饱和”时才积分
    bool allow_integ = (u == u_unsat) ||
                       ((u_unsat > pi->out_max) && (err < 0)) ||
                       ((u_unsat < pi->out_min) && (err > 0));

    if (allow_integ){
        pi->integ += pi->ki * err * dt;
        pi->integ = clampf(pi->integ, pi->integ_min, pi->integ_max);
    }
    return u;
}

void setPhaseVoltage(MotorFOC_t* motor, TIM_HandleTypeDef* htim){
    const float sqrt3_half = 0.86602540378f;   // sqrt(3)/2
    float angle_e = motor->electrical_angle;

    // 用速度环输出的 Vq 发矢量（保持 Vd=0）
    float Vq = clampf(motor->vq, -V_LIMIT, V_LIMIT);

    // Park^-1：dq -> αβ （设置 Vd=0，只用 Vq）
    float Ualpha = -Vq * arm_sin_f32(angle_e);
    float Ubeta  =  Vq * arm_cos_f32(angle_e);

    // αβ -> 三相（SVPWM 电压法）
    float duty_a = 0.5f + Ualpha / VBUS;
    float duty_b = 0.5f + (-0.5f*Ualpha + sqrt3_half*Ubeta) / VBUS;
    float duty_c = 0.5f + (-0.5f*Ualpha - sqrt3_half*Ubeta) / VBUS;

    apply_pwm_duty_abc(duty_a, duty_b, duty_c, motor, htim);
}


void velocityOpenloop(MotorFOC_t* motor, TIM_HandleTypeDef* htim, int motor_ID){
    static uint32_t t_ctrl = 0, t_print = 0;
    uint32_t now_us = micros();
    uint32_t dt_us  = (uint32_t)(now_us - t_ctrl);

    if (dt_us >= CTRL_DT_US){
        t_ctrl = now_us;
        // float dt = dt_us * 1e-6f;

        // 1) 采样/测速（你原来的）
        Read_Current_From_DRV8323(&motor->current[0], &motor->current[1], motor_ID);
        speed_task(motor_ID);
        elec_angle_from_hall(motor, &hall_m[motor_ID], motor_ID);
        float v_adc = (adc5_raw * VDDA) / 4095.0f;
        VBUS = v_adc * K_DIV;   // 总线电压（V）


       /* // 2) 速度环：e = 目标 - 反馈（用已经LPF后的速度）
        float speed_meas = motor->mechanical_speed;     // rpm（已滤波）
        float speed_ref  = motor->speed_ref_rpm;        // 目标 rpm
        float e_rpm = speed_ref - speed_meas;

        // 3) PI → Vq（单位伏特，带正负号，内部带防饱和）
        float vq_cmd = pi_update(&spdPI, e_rpm, dt);*/
        //motor->vq = 3;

        // 4) 发 SVPWM
        setPhaseVoltage(motor, htim);
    }

    // 打印（可选）
    if ((uint32_t)(now_us - t_print) >= PRINT_DT_US){
        t_print = now_us;
        //printf("ia=%.3f, ib=%.3f, ", motor->current[0], motor->current[1]);
        //printf(" rpm=%.1f VBUS= %.2f,  duty=[%.2f %.2f %.2f]\r\n", motor->mechanical_speed,  VBUS, motor->duty_ratio[0], motor->duty_ratio[1], motor->duty_ratio[2]);
        printf("%.1f		%.1f\r\n",target_e_rads, motor->mechanical_speed);
    }
}

static inline void apply_pwm_duty_abc(float da, float db, float dc, MotorFOC_t* motor, TIM_HandleTypeDef* htim)
{
    // 限幅到 [0,1]
    if(da<0.f) da=0.05f; else if(da>1.f) da=0.95f;
    if(db<0.f) db=0.05f; else if(db>1.f) db=0.95f;
    if(dc<0.f) dc=0.05f; else if(dc>1.f) dc=0.95f;

    __HAL_TIM_SET_COMPARE(htim, TIM_CHANNEL_1, da * PWM_PERIOD);
    __HAL_TIM_SET_COMPARE(htim, TIM_CHANNEL_2, db * PWM_PERIOD);
    __HAL_TIM_SET_COMPARE(htim, TIM_CHANNEL_3, dc * PWM_PERIOD);

    // 同步更新显示（可选）
    motor->duty_ratio[0]=da;
    motor->duty_ratio[1]=db;
    motor->duty_ratio[2]=dc;
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
